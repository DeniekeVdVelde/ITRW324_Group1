<?php
include_once('config.php');
error_reporting(E_ALL);

//create variables
$art_id = isset($_GET['art_id']) ?
mysqli_real_escape_string($_GET['$art_id']) : "";
$art_name = isset($_GET['art_name']) ?
mysqli_real_escape_string($_GET['$art_name']) : "";
$art_author = isset($_GET['art_author']) ?
mysqli_real_escape_string($_GET['$art_author']) : "";
$art_valRate = isset($_GET['art_valRate']) ?
mysqli_real_escape_string($_GET['$art_valRate']) : "";

//delete article from database
$delete = "DELETE FROM tbl_validated WHERE art_id=12";

if(mysqli_query($con, $delete))
{
	echo "Record was deleted successfully";
}
else
{
	echo "Error deleting record: " . mysqli_error($con);
}
?>
<?php

	$articleTitle = $_REQUEST['art_title'];
	$articleAuth = $_REQUEST['art_auth'];
	$articleDate = $_REQUEST['art_date'];
	$articleSubHead = $_REQUEST['art_subHead'];
	$articleContent = $_REQUEST['art_content'];
	$articleImageLocation = $_REQUEST['art_image_location'];
	
	include_once('config.php');
	error_reporting(E_ALL);

	
	//insert new article
	$insert = "INSERT INTO tbl_validated(art_id,art_title,art_subHead,art_content,art_author,art_date,art_image_location) VALUES
	(NULL,'$articleTitle','$articleSubHead','$articleContent','$articleAuth','$articleDate','$articleImageLocation')";

	$query = mysqli_query($con, $insert);
?>
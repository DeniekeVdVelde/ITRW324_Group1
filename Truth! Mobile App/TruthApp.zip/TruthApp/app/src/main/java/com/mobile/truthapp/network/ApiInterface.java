package com.mobile.truthapp.network;

import com.mobile.truthapp.model.Article;

import java.util.List;

import com.mobile.truthapp.model.Article;
import retrofit2.Call;
import retrofit2.http.GET;

/**
 * Created by Ravi Tamada on 21/02/17.
 * www.androidhive.info
 */

public interface ApiInterface {
    @GET("app_feed.php")
    Call<List<Article>> getInbox();
}

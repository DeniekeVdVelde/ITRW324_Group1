package com.mobile.truthapp.model;

/**
 * Created by Denieke vd Velde on 2017/10/21.
 */

public class Article {
    private int art_id;
    private String art_title;
    private String art_summary;
    private String art_date;
    private String art_image_location;
    private int color = -1;

    public Article(){}

    public int getId() {
        return art_id;
    }
    public void setId(int art_id) {
        this.art_id = art_id;
    }
    public void setTitle(String art_title){this.art_title = art_title;}
    public String getTitle(){return art_title;}
    public String getTimestamp() {
        return art_date;
    }
    public void setTimestamp(String timestamp) {
        this.art_date = timestamp;
    }
    public String getArt_image_location() {
        return art_image_location;
    }
    public void setArt_image_location(String art_image_location) {
        this.art_image_location = art_image_location;
    }
    public void setArt_summary(String art_summary){this.art_summary = art_summary;}
    public String getArt_summary(){return art_summary;}
    public int getColor() {
        return color;
    }
    public void setColor(int color) {
        this.color = color;
    }
}

